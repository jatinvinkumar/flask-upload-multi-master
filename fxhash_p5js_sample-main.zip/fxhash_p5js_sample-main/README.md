# fxhash p5js sample roject
A sample project for fxhash. 
Make sure that index.html is in the root of the zip you upload.
